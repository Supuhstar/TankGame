﻿[System.AttributeUsage( System.AttributeTargets.Method )]
public class dfEventProxyAttribute : System.Attribute
{
}
